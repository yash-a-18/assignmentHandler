from django.contrib import admin
from manageSubmissions.models import Submission
# Register your models here.
admin.site.register(Submission) 
