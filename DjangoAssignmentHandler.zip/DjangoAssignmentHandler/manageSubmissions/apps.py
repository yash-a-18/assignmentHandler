from django.apps import AppConfig


class ManagesubmissionsConfig(AppConfig):
    name = 'manageSubmissions'
