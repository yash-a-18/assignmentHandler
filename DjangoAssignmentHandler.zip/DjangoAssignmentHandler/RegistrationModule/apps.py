from django.apps import AppConfig


class RegistrationmoduleConfig(AppConfig):
    name = 'RegistrationModule'
