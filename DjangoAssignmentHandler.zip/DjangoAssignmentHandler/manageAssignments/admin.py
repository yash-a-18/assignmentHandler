from django.contrib import admin
from manageAssignments.models import Assignment
# Register your models here.
admin.site.register(Assignment)
