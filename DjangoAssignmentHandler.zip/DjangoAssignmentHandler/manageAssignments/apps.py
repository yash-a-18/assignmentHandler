from django.apps import AppConfig


class ManageassignmentsConfig(AppConfig):
    name = 'manageAssignments'
